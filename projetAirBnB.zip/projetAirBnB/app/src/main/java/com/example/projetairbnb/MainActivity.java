package com.example.projetairbnb;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static String jsonUrl = "https://public.opendatasoft.com/api/records/1.0/search/?dataset=airbnb-listings&q=&facet=host_response_time&facet=host_response_rate&facet=host_verifications&facet=city&facet=country&facet=property_type&facet=room_type&facet=bed_type&facet=amenities&facet=availability_365&facet=cancellation_policy&facet=features";
    ListView lv;
    List<Airbnb> airbnbList = new ArrayList<Airbnb>();
    AirbnbAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lv = findViewById(R.id.listview);
        adapter = new AirbnbAdapter(MainActivity.this , airbnbList);
        lv.setAdapter(adapter);

        new MyAsyncTask().execute(jsonUrl, airbnbList);


    }

}