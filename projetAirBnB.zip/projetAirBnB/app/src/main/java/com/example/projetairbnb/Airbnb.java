package com.example.projetairbnb;

public class Airbnb {

    private String city;
    private String score;
    private String name;
    private String price;

    public Airbnb(String name, String city, String score, String price){
        this.name = name ;
        this.city = city ;
        this.score = score ;
        this.price = price ;

    }

    public String getName() {
        return name;
    }
    public String getCity() {
        return city;
    }
    public String getScore() {
        return score;
    }
    public String getPrice() {
        return price;
    }


    public void setName(String name) {
        this.name = name;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public void setScore(String score) {
        this.score = score;
    }
    public void setPrice(String price) {
        this.price = price;
    }


}
