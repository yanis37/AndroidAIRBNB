package com.example.projetairbnb;

import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

public class MyAsyncTask extends AsyncTask<Object, Void, String> {

    private URL url;
    private HttpsURLConnection urlConnection;
    private String message;
    List<Airbnb> airbnbList = new ArrayList<Airbnb>();


    @Override
    protected String doInBackground(Object... params) {

        String str = (String) params[0];
        airbnbList = (List) params[1];

        try {
            url = new URL(str);
            HttpsURLConnection urlConnection = (HttpsURLConnection) url.openConnection();
            if (urlConnection.getResponseCode() == HttpsURLConnection.HTTP_OK) {
                // chargement du flux
                InputStreamReader isr = new InputStreamReader(urlConnection.getInputStream());
                BufferedReader input = new BufferedReader(isr);
                StringBuilder stringBuilder = new StringBuilder();
                String temp;
                while ((temp = input.readLine()) != null) {
                    stringBuilder.append(temp);
                }
                String jsonStr = stringBuilder.toString();
                parsJSON(jsonStr);
                urlConnection.disconnect();

                // parsage du flux
                input.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

        @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
    }

    public void parsJSON(String str){
        int i;

        try{
            JSONObject jsonObject = new JSONObject(str);
            JSONArray records = jsonObject.getJSONArray("records");



            for (i=0; i<records.length(); i++){
                JSONObject fields = records.getJSONObject(i).getJSONObject("fields");

                String name = fields.getString("name");
                String city = fields.getString("city");
                String price = fields.getString("price");
                String score = fields.getString("review_scores_rating");

                Log.d("TAG", name);
                Log.d("TAG", city);
                Log.d("TAG", score);
                Log.d("TAG", price);

                Airbnb airbnb = new Airbnb(name,city,score,price);
                airbnbList.add(airbnb);
                Log.d("tab", airbnbList.get(0).getPrice());


            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


}
